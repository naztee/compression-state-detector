from AlgorithmImports import *
from statistics import median
from collections import deque

class SymbolState:

    def __init__(self, symbol, market_cap_symbol, base):
        self.symbol = symbol
        self.market_cap_symbol = market_cap_symbol
        self.base = base
        self.bars = deque(maxlen=700)
        self.market_data = deque(maxlen=700)
        self.last_market_time = None
        self.last_price_time = None
        self.historical_peak = None
        self.last_eval_date = None
EMBEDDED_TICKERS = ['A2ZUSDT', 'AAVEUSDT', 'ACEUSDT', 'ACHUSDT', 'ACTUSDT', 'ACXUSDT', 'ADAUSDT', 'AERGOUSDT', 'AEROUSDT', 'AEVOUSDT', 'AGIXUSDT', 'AGLDUSDT', 'AGTUSDT', 'AI16ZUSDT', 'AIAUSDT', 'AINUSDT', 'AIOTUSDT', 'AIOUSDT', 'AIUSDT', 'AIXBTUSDT', 'AKEUSDT', 'AKTUSDT', 'ALCHUSDT', 'ALGOUSDT', 'ALICEUSDT', 'ALLUSDT', 'ALPACAUSDT', 'ALPHAUSDT', 'ALPINEUSDT', 'ALTUSDT', 'AMBUSDT', 'ANIMEUSDT', 'ANKRUSDT', 'ANTUSDT', 'APEUSDT', 'API3USDT', 'APTUSDT', 'ARBUSDT', 'ARCUSDT', 'ARIAUSDT', 'ARKMUSDT', 'ARKUSDT', 'ARPAUSDT', 'ARUSDT', 'ASRUSDT', 'ASTERUSDT', 'ASTRUSDT', 'ATAUSDT', 'ATHUSDT', 'ATOMUSDT', 'AUCTIONUSDT', 'AUDIOUSDT', 'AVAAIUSDT', 'AVAUSDT', 'AVAXUSDT', 'AVNTUSDT', 'AWEUSDT', 'AXLUSDT', 'AXSUSDT', 'B2USDT', 'B3USDT', 'BABYUSDT', 'BADGERUSDT', 'BAKEUSDT', 'BALUSDT', 'BANANAS31USDT', 'BANANAUSDT', 'BANDUSDT', 'BANKUSDT', 'BANUSDT', 'BARDUSDT', 'BASUSDT', 'BATUSDT', 'BBUSDT', 'BELUSDT', 'BERAUSDT', 'BICOUSDT', 'BIDUSDT', 'BIGTIMEUSDT', 'BIOUSDT', 'BLESSUSDT', 'BLUAIUSDT', 'BLURUSDT', 'BLZUSDT', 'BNBUSDT', 'BNTUSDT', 'BNXUSDT', 'BOMEUSDT', 'BONDUSDT', 'BRETTUSDT', 'BROCCOLI714USDT', 'BROCCOLIF3BUSDT', 'BRUSDT', 'BSVUSDT', 'BSWUSDT', 'BTCSTUSDT', 'BTCUSDT', 'BTRUSDT', 'BTSUSDT', 'BULLAUSDT', 'C98USDT', 'CAKEUSDT', 'CARVUSDT', 'CATIUSDT', 'CELOUSDT', 'CELRUSDT', 'CETUSUSDT', 'CFXUSDT', 'CGPTUSDT', 'CHESSUSDT', 'CHILLGUYUSDT', 'CHRUSDT', 'CHZUSDT', 'CKBUSDT', 'CLOUSDT', 'COAIUSDT', 'COCOSUSDT', 'COMBOUSDT', 'COMPUSDT', 'COOKIEUSDT', 'COSUSDT', 'COTIUSDT', 'COWUSDT', 'CROSSUSDT', 'CRVUSDT', 'CTKUSDT', 'CTSIUSDT', 'CUDISUSDT', 'CVCUSDT', 'CVXUSDT', 'CYBERUSDT', 'DAMUSDT', 'DARUSDT', 'DASHUSDT', 'DEEPUSDT', 'DEGENUSDT', 'DEGOUSDT', 'DENTUSDT', 'DEXEUSDT', 'DFUSDT', 'DGBUSDT', 'DIAUSDT', 'DMCUSDT', 'DOGEUSDT', 'DOGSUSDT', 'DOLOUSDT', 'DOODUSDT', 'DOTUSDT', 'DRIFTUSDT', 'DUSKUSDT', 'DYDXUSDT', 'DYMUSDT', 'EDENUSDT', 'EDUUSDT', 'EGLDUSDT', 'EIGENUSDT', 'ENAUSDT', 'ENJUSDT', 'ENSOUSDT', 'ENSUSDT', 'EOSUSDT', 'EPICUSDT', 'EPTUSDT', 'ERAUSDT', 'ESPORTSUSDT', 'ETCUSDT', 'ETHFIUSDT', 'ETHUSDT', 'ETHWUSDT', 'EULUSDT', 'EVAAUSDT', 'FARTCOINUSDT', 'FETUSDT', 'FFUSDT', 'FHEUSDT', 'FIDAUSDT', 'FILUSDT', 'FIOUSDT', 'FISUSDT', 'FLMUSDT', 'FLOCKUSDT', 'FLOWUSDT', 'FLUIDUSDT', 'FLUXUSDT', 'FORMUSDT', 'FORTHUSDT', 'FRONTUSDT', 'FTMUSDT', 'FTTUSDT', 'FUNUSDT', 'FXSUSDT', 'GALAUSDT', 'GALUSDT', 'GASUSDT', 'GHSTUSDT', 'GIGGLEUSDT', 'GLMRUSDT', 'GLMUSDT', 'GMTUSDT', 'GMXUSDT', 'GOATUSDT', 'GPSUSDT', 'GRASSUSDT', 'GRIFFAINUSDT', 'GRTUSDT', 'GTCUSDT', 'GUNUSDT', 'HAEDALUSDT', 'HANAUSDT', 'HBARUSDT', 'HEIUSDT', 'HEMIUSDT', 'HFTUSDT', 'HIFIUSDT', 'HIGHUSDT', 'HIPPOUSDT', 'HIVEUSDT', 'HMSTRUSDT', 'HNTUSDT', 'HOLOUSDT', 'HOMEUSDT', 'HOOKUSDT', 'HOTUSDT', 'HUMAUSDT', 'HYPERUSDT', 'HYPEUSDT', 'ICNTUSDT', 'ICPUSDT', 'ICXUSDT', 'IDEXUSDT', 'IDOLUSDT', 'IDUSDT', 'ILVUSDT', 'IMXUSDT', 'INITUSDT', 'INJUSDT', 'INUSDT', 'IOSTUSDT', 'IOTAUSDT', 'IOTXUSDT', 'IOUSDT', 'IPUSDT', 'JASMYUSDT', 'JELLYJELLYUSDT', 'JOEUSDT', 'JSTUSDT', 'JTOUSDT', 'JUPUSDT', 'KAIAUSDT', 'KAITOUSDT', 'KASUSDT', 'KAVAUSDT', 'KDAUSDT', 'KERNELUSDT', 'KEYUSDT', 'KGENUSDT', 'KLAYUSDT', 'KMNOUSDT', 'KNCUSDT', 'KOMAUSDT', 'KSMUSDT', 'LABUSDT', 'LAUSDT', 'LAYERUSDT', 'LDOUSDT', 'LEVERUSDT', 'LIGHTUSDT', 'LINAUSDT', 'LINEAUSDT', 'LINKUSDT', 'LISTAUSDT', 'LITUSDT', 'LOKAUSDT', 'LOOMUSDT', 'LPTUSDT', 'LQTYUSDT', 'LRCUSDT', 'LSKUSDT', 'LTCUSDT', 'LUMIAUSDT', 'LYNUSDT', 'MAGICUSDT', 'MANAUSDT', 'MANTAUSDT', 'MASKUSDT', 'MATICUSDT', 'MAVIAUSDT', 'MAVUSDT', 'MBLUSDT', 'MBOXUSDT', 'MDTUSDT', 'MELANIAUSDT', 'MEMEFIUSDT', 'MEMEUSDT', 'MERLUSDT', 'METISUSDT', 'METUSDT', 'MEUSDT', 'MEWUSDT', 'MILKUSDT', 'MINAUSDT', 'MIRAUSDT', 'MITOUSDT', 'MKRUSDT', 'MLNUSDT', 'MOCAUSDT', 'MONUSDT', 'MOODENGUSDT', 'MORPHOUSDT', 'MOVEUSDT', 'MOVRUSDT', 'MTLUSDT', 'MUBARAKUSDT', 'MYROUSDT', 'MYXUSDT', 'NAORISUSDT', 'NEARUSDT', 'NEIROETHUSDT', 'NEIROUSDT', 'NEOUSDT', 'NEWTUSDT', 'NFPUSDT', 'NILUSDT', 'NKNUSDT', 'NMRUSDT', 'NOMUSDT', 'NOTUSDT', 'NTRNUSDT', 'NULSUSDT', 'NXPCUSDT', 'OBOLUSDT', 'OCEANUSDT', 'OGNUSDT', 'OGUSDT', 'OLUSDT', 'OMGUSDT', 'OMNIUSDT', 'OMUSDT', 'ONDOUSDT', 'ONEUSDT', 'ONGUSDT', 'ONTUSDT', 'OPENUSDT', 'OPUSDT', 'ORBSUSDT', 'ORCAUSDT', 'ORDERUSDT', 'ORDIUSDT', 'OXTUSDT', 'PARTIUSDT', 'PAXGUSDT', 'PENDLEUSDT', 'PENGUUSDT', 'PEOPLEUSDT', 'PERPUSDT', 'PHAUSDT', 'PHBUSDT', 'PIPPINUSDT', 'PIXELUSDT', 'PLAYUSDT', 'PLUMEUSDT', 'PNUTUSDT', 'POLUSDT', 'POLYXUSDT', 'PONKEUSDT', 'POPCATUSDT', 'PORT3USDT', 'PORTALUSDT', 'POWRUSDT', 'PROMPTUSDT', 'PROMUSDT', 'PROVEUSDT', 'PTBUSDT', 'PUFFERUSDT', 'PUMPBTCUSDT', 'PUMPUSDT', 'PUNDIXUSDT', 'PYTHUSDT', 'QNTUSDT', 'QTUMUSDT', 'QUICKUSDT', 'QUSDT', 'RADUSDT', 'RAREUSDT', 'RAYSOLUSDT', 'RAYUSDT', 'RDNTUSDT', 'RECALLUSDT', 'REDUSDT', 'REEFUSDT', 'REIUSDT', 'RENDERUSDT', 'RENUSDT', 'RESOLVUSDT', 'REZUSDT', 'RIFUSDT', 'RIVERUSDT', 'RLCUSDT', 'RNDRUSDT', 'RONINUSDT', 'ROSEUSDT', 'RPLUSDT', 'RSRUSDT', 'RUNEUSDT', 'RVNUSDT', 'RVVUSDT', 'SAFEUSDT', 'SAGAUSDT', 'SAHARAUSDT', 'SANDUSDT', 'SANTOSUSDT', 'SAPIENUSDT', 'SCRTUSDT', 'SCRUSDT', 'SCUSDT', 'SEIUSDT', 'SFPUSDT', 'SHELLUSDT', 'SIGNUSDT', 'SIRENUSDT', 'SKATEUSDT', 'SKLUSDT', 'SKYAIUSDT', 'SKYUSDT', 'SLERFUSDT', 'SLPUSDT', 'SNTUSDT', 'SNXUSDT', 'SOLUSDT', 'SOLVUSDT', 'SOMIUSDT', 'SONICUSDT', 'SOONUSDT', 'SOPHUSDT', 'SPELLUSDT', 'SPKUSDT', 'SPXUSDT', 'SQDUSDT', 'SRMUSDT', 'SSVUSDT', 'STBLUSDT', 'STEEMUSDT', 'STGUSDT', 'STMXUSDT', 'STORJUSDT', 'STOUSDT', 'STPTUSDT', 'STRAXUSDT', 'STRKUSDT', 'STXUSDT', 'SUIUSDT', 'SUNUSDT', 'SUPERUSDT', 'SUSDT', 'SUSHIUSDT', 'SWARMSUSDT', 'SWELLUSDT', 'SXPUSDT', 'SXTUSDT', 'SYNUSDT', 'SYRUPUSDT', 'SYSUSDT', 'TACUSDT', 'TAGUSDT', 'TAIKOUSDT', 'TAKEUSDT', 'TANSSIUSDT', 'TAOUSDT', 'TAUSDT', 'THETAUSDT', 'THEUSDT', 'TIAUSDT', 'TLMUSDT', 'TNSRUSDT', 'TOKENUSDT', 'TOMOUSDT', 'TONUSDT', 'TOSHIUSDT', 'TOWNSUSDT', 'TRADOORUSDT', 'TRBUSDT', 'TREEUSDT', 'TROYUSDT', 'TRUMPUSDT', 'TRUTHUSDT', 'TRUUSDT', 'TRXUSDT', 'TSTUSDT', 'TURBOUSDT', 'TUSDT', 'TUTUSDT', 'TWTUSDT', 'UBUSDT', 'UMAUSDT', 'UNFIUSDT', 'UNIUSDT', 'USDCUSDT', 'USELESSUSDT', 'USTCUSDT', 'USUALUSDT', 'UXLINKUSDT', 'VANAUSDT', 'VANRYUSDT', 'VELODROMEUSDT', 'VELVETUSDT', 'VETUSDT', 'VFYUSDT', 'VICUSDT', 'VIDTUSDT', 'VINEUSDT', 'VIRTUALUSDT', 'VOXELUSDT', 'VTHOUSDT', 'VVVUSDT', 'WALUSDT', 'WAVESUSDT', 'WAXPUSDT', 'WCTUSDT', 'WIFUSDT', 'WLDUSDT', 'WLFIUSDT', 'WOOUSDT', 'WUSDT', 'XAIUSDT', 'XANUSDT', 'XCNUSDT', 'XEMUSDT', 'XLMUSDT', 'XMRUSDT', 'XNYUSDT', 'XPINUSDT', 'XPLUSDT', 'XRPUSDT', 'XTZUSDT', 'XVGUSDT', 'XVSUSDT', 'YALAUSDT', 'YBUSDT', 'YFIUSDT', 'YGGUSDT', 'ZBTUSDT', 'ZECUSDT', 'ZENUSDT', 'ZEREBROUSDT', 'ZETAUSDT', 'ZILUSDT', 'ZKCUSDT', 'ZKJUSDT', 'ZKUSDT', 'ZORAUSDT', 'ZRCUSDT', 'ZROUSDT', 'ZRXUSDT']

class CombinedAltcoinCompressionStudy(QCAlgorithm):
    MIN_MARKET_CAP = 1000000
    MAX_MARKET_CAP = 20000000
    SEGMENT_DAYS = 21
    TRAJECTORY_DAYS = 84
    NEW_LOW_LOOKBACK = 30
    REQUIRED_ALIGNED_DAYS = TRAJECTORY_DAYS + NEW_LOW_LOOKBACK
    EARLY_SCORE = 60
    MATURE_SCORE = 75
    EXTREME_SCORE = 90
    HORIZONS = [7, 14, 30, 60, 90]
    MIN_SIGNAL_GAP_DAYS = 14
    MARKET_MAX_AGE_DAYS = 2
    PRIOR_ACTIVITY_MIN = 0.2
    PRIOR_ACTIVITY_ALT = 0.3
    Q4_TURNOVER_MAX = 0.15
    Q4_RETURN_MIN = -0.08
    MIN_FALLING_TRANSITIONS = 2
    VARIANTS = (
        'V20_BASE',
        'DEEP_DD',
        'NEAR_QVWAP',
        'QVWAP_RECLAIM',
        'COMBINED_NEAR',
        'COMBINED_RECLAIM',
    )

    def initialize(self):
        self.set_start_date(2021, 8, 1)
        self.set_end_date(2026, 7, 31)
        self.set_time_zone(TimeZones.UTC)
        self.set_brokerage_model(BrokerageName.BINANCE_FUTURES, AccountType.MARGIN)
        self.set_account_currency('USDT', 100000)
        self.watchlist = list(EMBEDDED_TICKERS)
        self.states = {}
        self.market_cap_to_state = {}
        self.detectors = {}
        self.open_records = {}
        self.records = []
        self.seen = {name: set() for name in self.VARIANTS}
        self.subscription_success = 0
        self.subscription_failed = 0
        self.funnel = {'evaluations': 0, 'aligned_ready': 0, 'mcap_pass': 0, 'prior_active': 0, 'q4_quiet': 0, 'net_contract': 0, 'two_falls': 0, 'q4_stable': 0, 'downside_better': 0, 'structural': 0, 'early_or_better': 0, 'mature_or_better': 0, 'extreme': 0, 'signals': 0}
        self.per_token = {}
        for ticker in self.watchlist:
            base = self.get_base(ticker)
            self.detectors[base] = {}
            self.open_records[base] = []
            self.per_token[base] = {'eval': 0, 'ready': 0, 'mcap': 0, 'active': 0, 'q4': 0, 'net': 0, 'falls': 0, 'stable': 0, 'decel': 0, 'struct': 0, 'early': 0, 'signals': 0}
            self.subscribe_symbol(ticker)
        self.set_warm_up(400, Resolution.DAILY)
        self.debug('====================================')
        self.debug('V21 - ALTCOIN DATA ANALYSIS + COMPRESSION STATE DETECTOR')
        self.debug('====================================')
        self.debug('CONTROL | V20 FROZEN RULE: MC=$1M-$20M | SCORE=30-59 | Q4=5-20% | LOC=12-18% | 3D>0')
        self.debug('OVERLAYS | DEEP DD=-80% TO -95% | NEAR QVWAP=+/-5% | RECLAIM=CROSS ABOVE QVWAP')

    @staticmethod
    def get_base(ticker):
        return ticker[:-4] if ticker.endswith('USDT') else ticker

    def subscribe_symbol(self, ticker):
        try:
            future = self.add_crypto_future(ticker, Resolution.DAILY, market=Market.BINANCE, fill_forward=False)
            base = self.get_base(ticker)
            mc_security = self.add_data(CoinGecko, base)
            state = SymbolState(future.symbol, mc_security.symbol, base)
            self.states[future.symbol] = state
            self.market_cap_to_state[mc_security.symbol] = state
            self.subscription_success += 1
        except Exception as exc:
            self.subscription_failed += 1
            self.debug(f'SKIP {ticker}: {exc}')

    def on_data(self, slice: Slice):
        self.update_market_data(slice)
        self.update_prices(slice)

    def update_market_data(self, slice):
        data = slice.get(CoinGecko)
        if not data:
            return
        for symbol, point in data.items():
            state = self.market_cap_to_state.get(symbol)
            if state is None:
                continue
            mc = float(point.market_cap)
            volume = float(point.volume)
            if mc <= 0 or volume < 0:
                continue
            state.market_data.append((point.end_time, mc, volume))
            state.last_market_time = point.end_time

    def update_prices(self, slice):
        for symbol, state in self.states.items():
            bar = slice.bars.get(symbol)
            if bar is None:
                continue
            if getattr(bar, 'is_fill_forward', False):
                continue
            state.bars.append(bar)
            state.last_price_time = bar.end_time
            high = float(bar.high)
            if state.historical_peak is None or high > state.historical_peak:
                state.historical_peak = high
            self.update_signal_outcomes(state, bar)
            day = bar.end_time.date()
            if state.last_eval_date == day:
                continue
            state.last_eval_date = day
            if not self.is_warming_up:
                self.evaluate_symbol(state, bar)

    def evaluate_symbol(self, state, bar):
        base = state.base
        s = self.per_token[base]
        f = self.funnel
        f['evaluations'] += 1
        s['eval'] += 1
        if not self.is_fresh(state.last_market_time, self.MARKET_MAX_AGE_DAYS):
            return
        m = self.calculate_trajectory_metrics(state)
        if m is None:
            return
        f['aligned_ready'] += 1
        s['ready'] += 1
        if not self.MIN_MARKET_CAP <= m['market_cap'] <= self.MAX_MARKET_CAP:
            return
        f['mcap_pass'] += 1
        s['mcap'] += 1
        if not 0.05 <= m['q4_turnover'] < 0.2:
            return
        f['q4_quiet'] += 1
        s['q4'] += 1
        if m['q4_return'] < -0.12:
            return
        f['q4_stable'] += 1
        s['stable'] += 1
        if not 30 <= m['compression_score'] < 60:
            return
        f['structural'] += 1
        s['struct'] += 1
        self.update_detector(base, m, True, bar)

    def calculate_trajectory_metrics(self, state):
        bars = list(state.bars)
        market = list(state.market_data)
        if len(bars) < self.REQUIRED_ALIGNED_DAYS or len(market) < self.REQUIRED_ALIGNED_DAYS:
            return None
        bd = {b.end_time.date(): b for b in bars}
        md = {t.date(): (float(mc), float(v)) for t, mc, v in market}
        days = sorted(set(bd) & set(md))
        if len(days) < self.REQUIRED_ALIGNED_DAYS:
            return None
        rows = []
        for d in days[-self.REQUIRED_ALIGNED_DAYS:]:
            b = bd[d]
            mc, v = md[d]
            if mc > 0:
                rows.append({'day': d, 'open': float(b.open), 'high': float(b.high), 'low': float(b.low), 'close': float(b.close), 'mc': mc, 'turnover': v / mc})
        if len(rows) < self.REQUIRED_ALIGNED_DAYS:
            return None
        rows = rows[-self.REQUIRED_ALIGNED_DAYS:]
        ts = self.NEW_LOW_LOOKBACK
        tr = rows[ts:ts + self.TRAJECTORY_DAYS]
        if len(tr) != self.TRAJECTORY_DAYS:
            return None
        qs = []
        for q in range(4):
            s = q * self.SEGMENT_DAYS
            seg = tr[s:s + self.SEGMENT_DAYS]
            tv = [x['turnover'] for x in seg if x['turnover'] >= 0]
            cl = [x['close'] for x in seg]
            hi = [x['high'] for x in seg]
            lo = [x['low'] for x in seg]
            if not tv or cl[0] <= 0:
                return None
            mid = median(cl)
            if mid <= 0:
                return None
            nl = 0
            for j in range(self.SEGMENT_DAYS):
                i = ts + s + j
                prior = rows[max(0, i - self.NEW_LOW_LOOKBACK):i]
                if prior and rows[i]['low'] < min((x['low'] for x in prior)):
                    nl += 1
            qs.append({'turnover': median(tv), 'return': cl[-1] / cl[0] - 1, 'range': (max(hi) - min(lo)) / mid, 'new_lows': nl})
        a, b, c, d = qs
        recent = [x['mc'] for x in tr[-7:] if x['mc'] > 0]
        if not recent:
            return None
        tvs = [x['turnover'] for x in qs]
        falls = sum((tvs[i + 1] < tvs[i] for i in range(3)))
        prior_active = a['turnover'] >= self.PRIOR_ACTIVITY_MIN or max(a['turnover'], b['turnover']) >= self.PRIOR_ACTIVITY_ALT
        q4_quiet = d['turnover'] < self.Q4_TURNOVER_MAX
        net_contract = d['turnover'] < a['turnover']
        two_falls = falls >= self.MIN_FALLING_TRANSITIONS
        q4_stable = d['return'] >= self.Q4_RETURN_MIN
        worst_prev = min(a['return'], b['return'], c['return'])
        downside_better = d['return'] >= worst_prev + 0.1
        structural = prior_active and q4_quiet and net_contract and two_falls and q4_stable and downside_better
        tsco = self.score_turnover(*tvs)
        ds = self.score_downside(*(x['return'] for x in qs))
        rs = self.score_range(*(x['range'] for x in qs))
        ls = self.score_new_lows(*(x['new_lows'] for x in qs))
        pen = self.abandonment_penalty(d['turnover'], d['return'])
        score = max(0, min(100, tsco * 0.3 + ds * 0.3 + rs * 0.2 + ls * 0.2 - pen))
        return {'market_cap': median(recent), 'q1_turnover': a['turnover'], 'q2_turnover': b['turnover'], 'q3_turnover': c['turnover'], 'q4_turnover': d['turnover'], 'q1_return': a['return'], 'q2_return': b['return'], 'q3_return': c['return'], 'q4_return': d['return'], 'q1_range': a['range'], 'q2_range': b['range'], 'q3_range': c['range'], 'q4_range': d['range'], 'q1_lows': a['new_lows'], 'q2_lows': b['new_lows'], 'q3_lows': c['new_lows'], 'q4_lows': d['new_lows'], 'turnover_score': tsco, 'downside_score': ds, 'range_score': rs, 'low_score': ls, 'penalty': pen, 'compression_score': score, 'compression_state': self.classify_state(score), 'prior_active': prior_active, 'q4_quiet': q4_quiet, 'net_contract': net_contract, 'two_falls': two_falls, 'q4_stable': q4_stable, 'downside_better': downside_better, 'structural': structural}

    def score_turnover(self, q1, q2, q3, q4):
        score = 0
        if q1 > q2:
            score += 20
        if q2 > q3:
            score += 20
        if q3 > q4:
            score += 20
        if q4 < 0.1:
            score += 25
        elif q4 < 0.15:
            score += 18
        elif q4 < 0.2:
            score += 10
        if q1 > 0:
            contraction = 1.0 - q4 / q1
            if contraction >= 0.8:
                score += 15
            elif contraction >= 0.6:
                score += 10
            elif contraction >= 0.4:
                score += 5
        return min(score, 100)

    def score_downside(self, q1, q2, q3, q4):
        score = 0
        if q2 > q1:
            score += 20
        if q3 > q2:
            score += 20
        if q4 > q3:
            score += 20
        if q4 >= -0.03:
            score += 25
        elif q4 >= -0.05:
            score += 20
        elif q4 >= -0.08:
            score += 12
        elif q4 >= -0.12:
            score += 5
        worst_previous = min(q1, q2, q3)
        improvement = q4 - worst_previous
        if improvement >= 0.3:
            score += 15
        elif improvement >= 0.2:
            score += 10
        elif improvement >= 0.1:
            score += 5
        return min(score, 100)

    def score_range(self, q1, q2, q3, q4):
        score = 0
        if q2 < q1:
            score += 20
        if q3 < q2:
            score += 20
        if q4 < q3:
            score += 20
        if q1 > 0:
            contraction = 1.0 - q4 / q1
            if contraction >= 0.6:
                score += 40
            elif contraction >= 0.4:
                score += 30
            elif contraction >= 0.25:
                score += 20
            elif contraction >= 0.1:
                score += 10
        return min(score, 100)

    def score_new_lows(self, q1, q2, q3, q4):
        score = 0
        if q2 <= q1:
            score += 15
        if q3 <= q2:
            score += 15
        if q4 <= q3:
            score += 20
        if q4 == 0:
            score += 50
        elif q4 <= 1:
            score += 40
        elif q4 <= 2:
            score += 25
        elif q4 <= 4:
            score += 10
        return min(score, 100)

    def abandonment_penalty(self, q4_turnover, q4_return):
        penalty = 0
        if q4_turnover < 0.1 and q4_return <= -0.15:
            penalty += 30
        elif q4_turnover < 0.1 and q4_return <= -0.1:
            penalty += 20
        elif q4_turnover < 0.15 and q4_return <= -0.12:
            penalty += 15
        if q4_turnover < 0.03 and q4_return < -0.05:
            penalty += 10
        return min(penalty, 40)

    def classify_state(self, score):
        if score < 40:
            return 'REPRICING'
        if score < 60:
            return 'COOLING'
        if score < 75:
            return 'EARLY'
        if score < 90:
            return 'MATURE'
        return 'EXTREME'

    def update_detector(self, base, metrics, eligible, bar=None):
        if not eligible or bar is None:
            return
        st = None
        for x in self.states.values():
            if x.base == base:
                st = x
                break
        bs = list(st.bars) if st else []
        if len(bs) < 85:
            return
        p = float(bar.close)
        low = min((float(x.low) for x in bs[-84:] if float(x.low) > 0))
        dist = p / low - 1
        if not 0.12 <= dist < 0.18:
            return
        r3 = p / float(bs[-4].close) - 1
        if r3 <= 0:
            return

        vwap = self.quarter_vwap(bs)
        vwap_dist = None
        near_vwap = False
        reclaimed_vwap = False
        if vwap is not None and vwap['current'] is not None and vwap['current'] > 0:
            vwap_dist = p / vwap['current'] - 1
            near_vwap = abs(vwap_dist) <= 0.05
            reclaimed_vwap = (
                vwap['previous'] is not None
                and vwap['previous'] > 0
                and vwap['previous_close'] < vwap['previous']
                and p >= vwap['current']
            )
        peak = st.historical_peak if st else None
        drawdown = p / peak - 1 if peak and peak > 0 else None
        deep_drawdown = drawdown is not None and -0.95 <= drawdown <= -0.80

        tests = {
            'V20_BASE': True,
            'DEEP_DD': deep_drawdown,
            'NEAR_QVWAP': near_vwap,
            'QVWAP_RECLAIM': reclaimed_vwap,
            'COMBINED_NEAR': deep_drawdown and near_vwap,
            'COMBINED_RECLAIM': deep_drawdown and reclaimed_vwap,
        }
        for variant, passed in tests.items():
            if passed and base not in self.seen[variant]:
                self.create_final_record(
                    variant, base, bar, metrics, dist, r3, drawdown, vwap_dist
                )
                self.seen[variant].add(base)
                self.funnel['signals'] += 1

    @staticmethod
    def quarter_key(timestamp):
        return timestamp.year, (timestamp.month - 1) // 3 + 1

    def quarter_vwap(self, bars):
        if len(bars) < 2:
            return None
        key = self.quarter_key(bars[-1].end_time)
        quarter = [x for x in bars if self.quarter_key(x.end_time) == key]
        if len(quarter) < 2:
            return None

        def value(items):
            denominator = sum(float(x.volume) for x in items if float(x.volume) > 0)
            if denominator <= 0:
                return None
            numerator = sum(
                ((float(x.high) + float(x.low) + float(x.close)) / 3.0)
                * float(x.volume)
                for x in items if float(x.volume) > 0
            )
            return numerator / denominator

        return {
            'current': value(quarter),
            'previous': value(quarter[:-1]),
            'previous_close': float(quarter[-2].close),
        }

    def create_final_record(self, variant, base, bar, metrics, dist, r3, drawdown, vwap_dist):
        r = {'variant': variant, 'token': base, 'time': self.time, 'price': float(bar.close), 'score': metrics['compression_score'], 'q4_turnover': metrics['q4_turnover'], 'dist_low': dist, 'r3': r3, 'drawdown': drawdown, 'vwap_dist': vwap_dist, 'mae': 0.0, 'mfe': 0.0, 'snapshots': {}, 'last_obs': self.time, 'obs_days': 0}
        self.records.append(r)
        self.open_records[base].append(r)

    def create_variant_record(self, *args, **kwargs):
        pass

    def create_frozen_record(self, *args, **kwargs):
        pass

    def create_signal(self, *args, **kwargs):
        pass

    def update_signal_outcomes(self, state, bar):
        records = self.open_records.get(state.base)
        if not records:
            return
        still = []
        for r in records:
            days = (self.time - r['time']).days
            if days <= 0:
                still.append(r)
                continue
            entry = r['price']
            r['mae'] = min(r['mae'], float(bar.low) / entry - 1)
            r['mfe'] = max(r['mfe'], float(bar.high) / entry - 1)
            r['last_obs'] = self.time
            r['obs_days'] = days
            for h in self.HORIZONS:
                if days >= h and h not in r['snapshots']:
                    r['snapshots'][h] = {
                        'mae': r['mae'],
                        'mfe': r['mfe'],
                        'return': float(bar.close) / entry - 1,
                    }
            if days < max(self.HORIZONS):
                still.append(r)
        self.open_records[state.base] = still

    def is_fresh(self, timestamp, max_age_days):
        if timestamp is None:
            return False
        seconds = (self.time - timestamp).total_seconds()
        return 0 <= seconds <= max_age_days * 86400

    @staticmethod
    def survival(current, previous):
        if previous <= 0:
            return 0.0
        return current / previous

    @staticmethod
    def percentile(values, p):
        if not values:
            return None
        ordered = sorted(values)
        if len(ordered) == 1:
            return ordered[0]
        idx = (len(ordered) - 1) * p
        lower = int(idx)
        upper = min(lower + 1, len(ordered) - 1)
        weight = idx - lower
        return ordered[lower] * (1 - weight) + ordered[upper] * weight

    def print_funnel(self):
        f = self.funnel
        steps = [('Total evaluations', f['evaluations']), ('114D aligned history ready', f['aligned_ready']), ('MC $1M-$20M', f['mcap_pass']), ('Q4 Vol/MC <20%', f['q4_quiet']), ('Q4 return >= -12%', f['q4_stable']), ('Compression score >=30', f['structural']), ('Score >=60 Early+', f['early_or_better']), ('Score >=75 Mature+', f['mature_or_better']), ('Score >=90 Extreme', f['extreme']), ('Frozen-rule signals', f['signals'])]
        self.debug('====================================')
        self.debug('V20 FINAL FUNNEL')
        self.debug('====================================')
        prev = None
        for label, val in steps:
            self.debug(f'{label}: {val}' if prev is None else f'{label}: {val} | step survival {self.survival(val, prev):.1%}')
            prev = val

    def print_signal_results(self):
        self.debug('====================================')
        self.debug('V21 COMBINED PROJECT - CENSOR-SAFE VARIANT TEST')
        self.debug('====================================')
        for variant in self.VARIANTS:
            rr = [x for x in self.records if x['variant'] == variant]
            self.debug('------------------------------------')
            self.debug(f"{variant} | ENTRIES={len(rr)} | TOKENS={len(set(x['token'] for x in rr))}")
            for h in self.HORIZONS:
                z = [x for x in rr if h in x['snapshots']]
                if not z:
                    self.debug(f'{variant} {h}D | N=0')
                    continue
                a = [x['snapshots'][h]['mae'] for x in z]
                e = [x['snapshots'][h]['mfe'] for x in z]
                returns = [x['snapshots'][h]['return'] for x in z]
                n = len(z)
                self.debug(
                    f'{variant} {h}D | N={n} | MED_RET={median(returns):.1%} '
                    f'| WIN={sum(x > 0 for x in returns) / n:.1%} '
                    f'| MED_MAE={median(a):.1%} | WORST={min(a):.1%} '
                    f'| P10_MAE={self.percentile(a, 0.1):.1%} '
                    f'| DD20={sum(x <= -0.2 for x in a) / n:.1%} '
                    f'| DD30={sum(x <= -0.3 for x in a) / n:.1%} '
                    f'| DD40={sum(x <= -0.4 for x in a) / n:.1%} '
                    f'| MED_MFE={median(e):.1%} '
                    f'| MFE20={sum(x >= 0.2 for x in e) / n:.1%} '
                    f'| MFE50={sum(x >= 0.5 for x in e) / n:.1%}'
                )

            full = [x for x in rr if 90 in x['snapshots']]
            incomplete = [x for x in rr if 90 not in x['snapshots']]
            self.debug(f'{variant} STATUS | FULL90={len(full)} | CENSORED={len(incomplete)}')
        self.debug('====================================')
        self.debug('TOKEN AUDIT')
        self.debug('====================================')
        for x in self.records:
            status = 'FULL90' if 90 in x['snapshots'] else 'RECENT' if (self.time - x['time']).days < 90 else 'STALE'
            mae = x['snapshots'][90]['mae'] if status == 'FULL90' else x['mae']
            mfe = x['snapshots'][90]['mfe'] if status == 'FULL90' else x['mfe']
            dd = 'NA' if x['drawdown'] is None else f"{x['drawdown']:.1%}"
            vwap_dist = 'NA' if x['vwap_dist'] is None else f"{x['vwap_dist']:.1%}"
            self.debug(f"{x['variant']} | {x['token']} | {status} | ENTRY={x['time'].date()} | FOLLOWUP={x['obs_days']}D | SCORE={x['score']:.1f} | Q4={x['q4_turnover']:.1%} | LOC={x['dist_low']:.1%} | R3={x['r3']:.1%} | DD={dd} | QVWAP_DIST={vwap_dist} | MAE={mae:.1%} | MFE={mfe:.1%}")

    def print_state_breakdown(self):
        pass

    def print_token_funnel(self):
        self.debug('====================================')
        self.debug('V21 VARIANT SAMPLE COUNTS')
        self.debug('====================================')
        for variant in self.VARIANTS:
            self.debug(f'{variant}: {len(self.seen[variant])} tokens')

    def on_end_of_algorithm(self):
        self.debug('====================================')
        self.debug('V21 COMBINED PROJECT STUDY COMPLETE')
        self.debug('====================================')
        self.debug(f'Symbols requested: {len(self.watchlist)}')
        self.debug(f'Subscriptions created: {self.subscription_success}')
        self.debug(f'Subscription failures: {self.subscription_failed}')
        self.print_funnel()
        self.print_signal_results()
        self.print_state_breakdown()
        self.print_token_funnel()
        self.debug('====================================')
